import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:urun_katalog_projesi/models/category_model.dart';
import 'package:urun_katalog_projesi/models/product_model.dart';
import 'package:urun_katalog_projesi/models/product_details.dart';
import 'product_cache.dart';  // Önbellek yönetim sınıfını içe aktar

class ProductRepository {
  final String baseUrl = "https://assign-api.piton.com.tr/api/rest";
  final ProductCache productCache = ProductCache(); // Önbellek sınıfını başlatın

  // Kategorileri getir
  Future<List<Category>> fetchCategories() async {
    final response = await http.get(Uri.parse('$baseUrl/categories'));

    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      return data.map((json) => Category.fromJson(json)).toList();
    } else {
      throw Exception("Failed to load categories");
    }
  }

  //Önbelleğe alma ile Kategori Kimliğine Göre Ürünleri Getir
  Future<List<Product>> fetchProductsByCategoryId(int categoryId) async {
    // Öncelikle önbelleğe alınmış verilerin mevcut olup olmadığını kontrol edin
    List<Product> cachedProducts = await productCache.getCachedProducts(categoryId);
    if (cachedProducts.isNotEmpty) {
      return cachedProducts;
    }

    // Değilse, API'den veri alın
    final response = await http.get(Uri.parse('$baseUrl/products/$categoryId'));

    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      List<Product> products = data.map((json) => Product.fromJson(json)).toList();

      // Alınan ürünleri gelecekte kullanmak üzere önbelleğe alın
      productCache.cacheProducts(categoryId, products);

      return products;
    } else {
      throw Exception("Failed to load products");
    }
  }

  // Ürün Ayrıntılarını Getir
  Future<ProductDetails> fetchProductDetails(int productId) async {
    final response = await http.get(Uri.parse('$baseUrl/products/$productId'));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return ProductDetails.fromJson(data);
    } else {
      throw Exception("Failed to load product details");
    }
  }
}
