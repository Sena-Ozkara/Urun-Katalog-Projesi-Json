import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:urun_katalog_projesi/models/product_model.dart';

class ProductCache {
  Future<List<Product>> getCachedProducts(int categoryId) async {
    final prefs = await SharedPreferences.getInstance();
    final cacheKey = 'category_$categoryId';
    final cachedData = prefs.getString(cacheKey);

    if (cachedData != null) {
      final cacheTimeKey = '$cacheKey' + '_time';
      final cacheTime = prefs.getInt(cacheTimeKey);

      // Önbelleğin hala geçerli olup olmadığını kontrol edin (24 saat içinde)
      if (cacheTime != null && DateTime.now().millisecondsSinceEpoch - cacheTime < 86400000) {
        //Önbelleğe alınan JSON dizesini List<dynamic> yerine List<Map<String, dynamic>> olarak kodlayın
        final List<dynamic> data = json.decode(cachedData);

        // JSON yapısı bir Harita Listesi ise, her birini bir Ürün nesnesine dönüştürün
        return data.map((jsonItem) => Product.fromJson(jsonItem as Map<String, dynamic>)).toList();
      }
    }
    return [];
  }

  Future<void> cacheProducts(int categoryId, List<Product> products) async {
    final prefs = await SharedPreferences.getInstance();
    final cacheKey = 'category_$categoryId';

    // Ürün nesnelerinin listesini List<Map<String, dynamic>>'e dönüştürün ve JSON olarak kodlayın
    final productsJson = json.encode(products.map((product) => product.toJson()).toList());
    await prefs.setString(cacheKey, productsJson);

    final cacheTimeKey = '$cacheKey' + '_time';
    await prefs.setInt(cacheTimeKey, DateTime.now().millisecondsSinceEpoch);
  }
}
