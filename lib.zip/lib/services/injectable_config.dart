import 'package:get_it/get_it.dart';
import 'package:urun_katalog_projesi/services/api_service.dart';

final getIt = GetIt.instance;

void $initGetIt(GetIt getIt) {
  getIt.registerLazySingleton<AuthService>(() => AuthService());
}