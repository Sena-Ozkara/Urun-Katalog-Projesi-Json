import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:urun_katalog_projesi/models/category_model.dart';
import 'package:urun_katalog_projesi/models/product_model.dart';

class ApiService {
  final String baseUrl = 'https://assign-api.piton.com.tr/api/rest/';

  Future<List<Category>> fetchCategories() async {
    final response = await http.get(Uri.parse('$baseUrl/categories'));
    if (response.statusCode == 200) {
      final Map<String, dynamic> jsonResponse = jsonDecode(response.body);
      if (jsonResponse['category'] is List) {
        final List<dynamic> categories = jsonResponse['category'];
        return categories
            .map((e) => Category.fromJson(e as Map<String, dynamic>))
            .toList();
      } else {
        throw Exception('Invalid format: category is not a list');
      }
    } else {
      throw Exception('Failed to load categories');
    }
  }


  // Fetch products by category ID
  Future<List<Product>> fetchProductsByCategory(int categoryId) async {
    final response = await http.get(Uri.parse('$baseUrl/products/$categoryId'));
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body) as List;
      return data.map((e) => Product.fromJson(e)).toList();
    } else {
      throw Exception('Failed to load products');
    }
  }


  
}
