import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

// AuthService sınıfı
class AuthService {
  final String _baseUrl = 'https://assign-api.piton.com.tr/api/rest';

  // Giriş yapmak için fonksiyon
  Future<Map<String, dynamic>> login({required String email, required String password}) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/login'),
      headers: {"Accept": "application/json"},

     // headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to login');
    }
  }

  // Kayıt olmak için fonksiyon
  Future<Map<String, dynamic>> register({required String name, required String email, required String password}) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'name': name, 'email': email, 'password': password}),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to register');
    }
  }


}

// AuthService Provider'ı tanımlıyoruz
final authServiceProvider = Provider<AuthService>((ref) => AuthService());

