import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:injectable/injectable.dart';


@injectable
class AuthService {
  final String _baseUrl = 'https://assign-api.piton.com.tr/api/rest';

  Future<Map<String, dynamic>> login({required String email, required String password}) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/login'),
      headers: {"Accept": "application/json"},

      //headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to login: ${response.statusCode} - ${response.body}');
    }
  }

  Future<Map<String, dynamic>> register({required String name, required String email, required String password}) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'name': name, 'email': email, 'password': password}),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      // Error message to debug
      throw Exception('Failed to register: ${response.statusCode} - ${response.body}');
    }
  }
}
