import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:urun_katalog_projesi/models/product_model.dart';
import 'package:urun_katalog_projesi/providers/providers.dart';
import 'package:urun_katalog_projesi/screens/product_details_screen.dart';

class ProductsScreen extends ConsumerWidget {
  final int categoryId;

  ProductsScreen({super.key, required this.categoryId});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final productAsyncValue = ref.watch(productProvider(categoryId)); // Kategori ID: 1

    return Scaffold(
      appBar: AppBar(
        title: Padding(
          padding: const EdgeInsets.only(left: 215.0),
          child: Text('Best Seller'),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: productAsyncValue.when(
        data: (products) {
          return ProductsGrid(products: products);
        },
        loading: () => Center(child: CircularProgressIndicator()),
        error: (error, _) => Center(child: Text('Error: $error')),
      ),
    );
  }
}

class ProductsGrid extends StatefulWidget {
  final List<Product> products;

  ProductsGrid({required this.products});

  @override
  _ProductsGridState createState() => _ProductsGridState();
}

class _ProductsGridState extends State<ProductsGrid> {
  late List<Product> filteredProducts;
  final TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    filteredProducts = widget.products;
  }

  void filterProducts(String query) {
    setState(() {
      filteredProducts = widget.products
          .where((product) =>
      product.title.toLowerCase().contains(query.toLowerCase()) ||
          product.author.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          // Arama Çubuğu
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: searchController,
                  onChanged: (value) => filterProducts(value),
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    hintText: "Search by title or author",
                    suffixIcon: IconButton(
                      icon: Icon(Icons.clear),
                      onPressed: () {
                        searchController.clear();
                        filterProducts('');
                      },
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                    fillColor: Color(0xFFE6E6FF),
                    filled: true,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 16),

          // Ürün GridView
          Expanded(
            child: GridView.builder(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
                childAspectRatio: 0.7,
              ),
              itemCount: filteredProducts.length,
              itemBuilder: (context, index) {
                final product = filteredProducts[index];
                return _buildProductCard(
                  context,
                  product.title,
                  product.author,
                  product.price.toString(),
                  product.image,
                  product.id,
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProductCard(
      BuildContext context, String title, String author, String price, String image,int id) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BookDetailsPage(
              title: title,
              id: id,
              author: author,
              price: price,
              imagePath: image,
              summary: 'Lorem ipsum summary goes here...',
            ),
          ),
        );
      },
      child: Container(
        padding: EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Color(0xFFE6E6FF),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          children: [
            // Ürün görseli
            Image.network(
              image,
              height: 150,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 8),
            // Ürün detayları
            Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
            Text(author, style: TextStyle(color: Colors.grey)),
            SizedBox(height: 8),
            Text("\$$price", style: TextStyle(color: Color(0xFF6251DD))),
          ],
        ),
      ),
    );
  }
}
