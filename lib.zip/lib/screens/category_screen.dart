import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:urun_katalog_projesi/models/category_model.dart';
import 'package:urun_katalog_projesi/models/product_model.dart';
import 'package:urun_katalog_projesi/providers/providers.dart';
import 'package:urun_katalog_projesi/screens/product_list_screen.dart';

class CategoriesScreen extends ConsumerWidget {
  final TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Ekran boyutlarını al
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;

    final categoryAsyncValue = ref.watch(categoryProvider);

    return Scaffold(
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Image.asset(
            'assets/logo.png',
            height: screenHeight * 0.2,
            width: screenWidth * 0.2,
          ),
        ),
        title: Padding(
          padding: const EdgeInsets.only(left: 225.0),
          child: Text('Catalog'),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Kategoriler
              categoryAsyncValue.when(
                data: (categories) {
                  return SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: categories
                          .map((category) =>
                          _buildCategoryCard(context, category))
                          .toList(),
                    ),
                  );
                },
                loading: () => Center(child: CircularProgressIndicator()),
                error: (error, stackTrace) => Text("Error: $error"),
              ),
              SizedBox(height: 16),

              // Arama Çubuğu
              TextField(
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: "Search",
                  suffixIcon: IconButton(
                    icon: Icon(Icons.filter_list),
                    onPressed: () {
                      // Filtre işlemi
                    },
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  fillColor: Color(0xFFE6E6FF),
                  filled: true,
                ),
              ),
              SizedBox(height: 16),

              // Best Seller Bölümü
              _buildSectionHeader(
                context,
                title: "Best Seller",
                onViewAllPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ProductsScreen(categoryId: 1),
                    ),
                  );
                },
              ),
              Consumer(
                builder: (context, ref, child) {
                  final bestSellerAsyncValue = ref.watch(productProvider(1));
                  return bestSellerAsyncValue.when(
                    data: (products) => _buildResponsiveBookRow(products),
                    loading: () => CircularProgressIndicator(),
                    error: (error, stackTrace) =>
                        Text("Error: $error"), // Hata durumunda gösterilecek
                  );
                },
              ),
              Consumer(
                builder: (context, ref, child) {
                  final bestSellerAsyncValue = ref.watch(productProvider(2));
                  return bestSellerAsyncValue.when(
                    data: (products) => _buildResponsiveBookRow(products),
                    loading: () => CircularProgressIndicator(),
                    error: (error, stackTrace) =>
                        Text("Error: $error"), // Hata durumunda gösterilecek
                  );
                },
              ),
              Consumer(
                builder: (context, ref, child) {
                  final bestSellerAsyncValue = ref.watch(productProvider(3));
                  return bestSellerAsyncValue.when(
                    data: (products) => _buildResponsiveBookRow(products),
                    loading: () => CircularProgressIndicator(),
                    error: (error, stackTrace) =>
                        Text("Error: $error"), // Hata durumunda gösterilecek
                  );
                },
              ),
              Consumer(
                builder: (context, ref, child) {
                  final bestSellerAsyncValue = ref.watch(productProvider(4));
                  return bestSellerAsyncValue.when(
                    data: (products) => _buildResponsiveBookRow(products),
                    loading: () => CircularProgressIndicator(),
                    error: (error, stackTrace) =>
                        Text("Error: $error"), // Hata durumunda gösterilecek
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryCard(BuildContext context, Category category) {
    return GestureDetector(
      onTap: () {

      },
      child: Container(
        margin: EdgeInsets.only(right: 8),
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Color(0xFFE6E6FF),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          category.name,
          style: TextStyle(color: Colors.black38, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(BuildContext context,
      {required String title, required VoidCallback onViewAllPressed}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        TextButton(
          onPressed: onViewAllPressed,
          child: Text(
            "View All",
            style: TextStyle(
              color: Color(0xFFEF6B4A),
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildResponsiveBookRow(List<Product> products) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: products.map((product) => _buildBookCard(product)).toList(),
      ),
    );
  }

  Widget _buildBookCard(Product product) {
    return Container(
      width: 200,
      margin: EdgeInsets.only(right: 8),
      decoration: BoxDecoration(
        color: Color(0xFFE6E6FF),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          // Ürün görüntüsü
          Image.network(
            product.image,
            height: 120,
            width: 70,
            fit: BoxFit.cover,
          ),
          SizedBox(width: 8),
          // Ürün bilgileri
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(product.title,
                    style: TextStyle(fontWeight: FontWeight.bold)),
                Text(product.author, style: TextStyle(color: Colors.grey)),
                SizedBox(height: 8),
                Text(product.price, style: TextStyle(color: Color(0xFF6251DD))),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
